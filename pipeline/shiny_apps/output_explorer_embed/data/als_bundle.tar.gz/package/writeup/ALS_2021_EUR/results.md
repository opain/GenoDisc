> **AUTOMATICALLY GENERATED DRAFT — CHECK AND EDIT BEFORE USE.**
> This results text was produced by the GenoDisc write-up generator (v0.1.0) from the recorded run configuration, software provenance and result objects (results schema v2, pipeline 1.6.0). It describes what the pipeline actually ran. It is a starting point, not a finished section: verify every number, version and citation, fill the `[CITE: ...]` placeholders, and edit for style before use. Citation keys (`@key`) refer to `references.bib` in this folder.
# Results — ALS 2021 (European Only) (EUR-ancestry)
LD-score regression estimated the observed-scale SNP-based heritability at 0.0649 (SE 0.0072) with an LD-score regression intercept of 1.03 (SE 0.0075) (Table W-ldsc-h2; see the Heritability tab of the Output Viewer, packaged block `gwas_qc`).

SumHer estimated the SNP-based heritability at 0.147 (SE 0.0135) under the BLD-LDAK model (Table W-sumher; see the Heritability tab of the Output Viewer, packaged block `gwas_qc`).

Genetic correlation was tested for 49 trait pairs; 9 were significant after FDR correction (P.FDR < 0.05). The strongest correlation was with ALS (rg = 1.15, SE 0.0981, P.FDR = 4.1e-30). (Table W-gencor; see the Genetic correlation tab of the Output Viewer, packaged block `gwas_qc`)

Clumping identified 83 independent genome-wide significant loci. The most significant was rs2453555 (nearest gene C9orf72, MOB3B (+34.09kb), IFNK (+37.37kb), CTAGE12P (-44.51kb)) (P = 1.0e-42) (Table W-clump; see the SNP associations tab of the Output Viewer, packaged block `snp_assoc`).

COJO identified 14 conditionally independent association signals. The strongest joint signal was rs2453554 (nearest gene C9orf72, MOB3B (+32.02kb), IFNK (+35.3kb), CTAGE12P (-46.58kb)) (joint P = 1.4e-42) (Table W-cojo; see the SNP associations tab of the Output Viewer, packaged block `snp_assoc`).

Credible-set coding annotation covered 17 credible sets; 3 carried at least half of their posterior inclusion probability on protein-altering variants. The credible set with the greatest protein-altering share (100%) implicated KIF5A (Table W-coding; see the Effector-genes tab of the Output Viewer, packaged block `credset_coding`).

MAGMA gene-level analysis tested 18,118 associations; 199 were significant after FDR correction (P.FDR < 0.05). The strongest association was MOB3B (P = 5.3e-15, P.FDR = 9.6e-11) (Table W-mol_assoc/magma; see the MAGMA tab of the Output Viewer, packaged block `mol_assoc/magma`).

Transcriptome-wide association analysis tested 36,812 associations; 154 were significant after FDR correction (P.FDR < 0.05), of which 90 also showed colocalisation support. The strongest association was C9orf72 in Brain - DLPFC (PsychENCODE) (P = 4.7e-16, P.FDR = 1.7e-11) (Table W-mol_assoc/exp/fusion; see the TWAS tab of the Output Viewer, packaged block `mol_assoc/exp/fusion`).

Proteome-wide association analysis tested 2,565 associations; 10 were significant after FDR correction (P.FDR < 0.05), of which 8 also showed colocalisation support. The strongest association was SCFD1 in Brain - DLPFC (ROSMAP) (P = 4.8e-15, P.FDR = 1.2e-11) (Table W-mol_assoc/protein/fusion; see the PWAS tab of the Output Viewer, packaged block `mol_assoc/protein/fusion`).

SMR of gene expression tested 25,912 associations; 45 were significant after FDR correction (P.FDR < 0.05), of which 27 also passed the HEIDI test (p_HEIDI > 0.05). The strongest association was SCFD1 in Blood (eQTLGen) (P = 1.2e-13, P.FDR = 3.2e-09) (Table W-mol_assoc/exp/smr; see the SMR tab of the Output Viewer, packaged block `mol_assoc/exp/smr`).

SMR of protein levels tested 599 associations; 5 were significant after FDR correction (P.FDR < 0.05), of which 4 also passed the HEIDI test (p_HEIDI > 0.05). The strongest association was SCFD1 in Brain - DLPFC (ROSMAP) (P = 4.4e-10, P.FDR = 2.6e-07) (Table W-mol_assoc/protein/smr; see the SMR tab of the Output Viewer, packaged block `mol_assoc/protein/smr`).

MAGMA tissue enrichment tested 54 tissues; 4 were FDR-significant. The most enriched was Brain - Cerebellum (P = 7.1e-05, P.FDR = 0.004). After conditional analysis, 2 tissue(s) remained: Brain - Cerebellar Hemisphere and Brain - Cerebellum. (Table W-tissue; see the Tissue tab of the Output Viewer, packaged block `tissue`)

CALDERA prioritised candidate causal genes across 15 credible sets. The highest single-gene causal probability was 0.752 for CFAP410 (Table W-caldera; see the Effector-genes tab of the Output Viewer, packaged block `caldera`).

MAGMA drug enrichment tested 1,453 sets; none were FDR-significant. Wilcoxon ATC-class enrichment found FDR-significant classes by ATC level - L2: 3, L3: 2, L4: 6 (top: N05: psycholeptics at L2, P.FDR = 2.3e-05). VIF-OLS ATC-class enrichment found no FDR-significant classes. GLS ATC-class enrichment found FDR-significant classes by ATC level - L2: 1, L3: 0, L4: 0 (top: H02: corticosteroids for systemic use at L2, P.FDR = 0.024). (see the Drug enrichment tab of the Output Viewer.)

MAGMA pathway enrichment tested 17,797 sets; none were FDR-significant. (see the Pathway tab of the Output Viewer.)
