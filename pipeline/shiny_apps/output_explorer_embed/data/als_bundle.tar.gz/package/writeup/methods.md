> **AUTOMATICALLY GENERATED DRAFT — CHECK AND EDIT BEFORE USE.**
> This methods text was produced by the GenoDisc write-up generator (v0.1.0) from the recorded run configuration, software provenance and result objects (results schema v2, pipeline 1.6.0). It describes what the pipeline actually ran. It is a starting point, not a finished section: verify every number, version and citation, fill the `[CITE: ...]` placeholders, and edit for style before use. Citation keys (`@key`) refer to `references.bib` in this folder.

# Methods

Summary statistics were quality-controlled and harmonised with the GenoDisc cleaning pipeline against the 1000 Genomes + HGDP reference panel (1000 Genomes Phase 3 + HGDP) [@1000genomes2015]. Variants were removed if the imputation INFO score was below 0.9, if the reported or reference minor-allele frequency (MAF) was below 0.01, or if the reported and reference MAF differed by more than 0.2; alleles were harmonised to the reference and strand-ambiguous and duplicate variants resolved. The genome build was identified as GRCh37. Of 10,461,755 variants in the input, 5,732,463 remained after QC.

SNP-based heritability on the observed scale and the LD-score regression intercept were estimated with LD Score Regression (LDSC) (git commit aa33296) [@bulik2015ldsc], using the European-ancestry HapMap3 LD scores supplied with the pipeline.

Genome-wide SNP-based heritability, polygenicity and per-annotation heritability enrichment were additionally estimated with the SBayesRC (R package) (v0.2.6) [@zheng2024sbayesrc].

SNP-based heritability was also estimated with LDAK SumHer (BLD-LDAK model) (ldak7.01) [@speed2017sumher] under the BLD-LDAK heritability model from pre-computed HapMap3 tagging files with large-effect predictors excluded at a per-SNP heritability cutoff of 0.01. The three heritability methods assume different models and are not expected to agree.

Genetic correlations were estimated using bivariate (cross-trait) cross-trait LD Score regression (genetic correlation) (git commit aa33296) [@bulik2015ldschrg] between the submitted summary statistics and a curated set of reference GWAS. Correlations were corrected for multiple testing across all tested pairs using the Benjamini–Hochberg procedure.

Independent genome-wide significant loci were identified by LD-based clumping in PLINK (v1.90b6.21) [@chang2015plink] using the 1000 Genomes + HGDP reference panel (1000 Genomes Phase 3 + HGDP) [@1000genomes2015], matched to the GWAS population (index-variant P < 1.0e-05, r2 < 0.1, 500 kb window). The nearest gene to each index variant was annotated.

Conditionally independent association signals were identified by stepwise conditional and joint (COJO) analysis with Manc-COJO (v1.1.0) [@wang2026manccojo; @yang2012cojo], using the 1000 Genomes + HGDP reference panel (1000 Genomes Phase 3 + HGDP) [@1000genomes2015], matched to the GWAS population (selection threshold P < 5.0e-08).

The protein-altering potential of each 95% credible set was characterised by predicting variant consequences against the Ensembl GRCh37 gene models with BCFtools/csq (v1.17) [@danecek2017bcftoolscsq] and scoring missense variants with AlphaMissense missense pathogenicity predictions (AlphaMissense GRCh37 precomputed) [@cheng2023alphamissense]. For each credible set the share of posterior inclusion probability carried by protein-altering variants was summarised to flag a possible coding mechanism.

Gene-level association was tested with MAGMA (v1.10) [@deleeuw2015magma], mapping variants to genes with a 35 kb upstream / 10 kb downstream window and aggregating variant P-values accounting for LD. Gene P-values were FDR-corrected.

Transcriptome-wide association analysis (TWAS) was performed with FUSION (git commit 4635dd1) [@gusev2016fusion] across 6 expression SNP-weight panels (Brain - Amygdala (GTEx), Brain - Cerebellar hemisphere (GTEx), Blood (GTEx), Blood (NTR), Blood (YFS) and Brain - DLPFC (PsychENCODE); 38,116 gene–tissue models) using PsychENCODE DLPFC TWAS SNP-weights (PEC_TWAS_weights) [@psychencode_twas] and GTEx v8 FUSION expression SNP-weights (GTEx v8) [@gtex2020]. Associations were corrected for multiple testing across all expression panels using the Benjamini–Hochberg procedure. Colocalisation of each significant association was assessed with coloc (v3.1) [@giambartolomei2014coloc].

Proteome-wide association analysis (PWAS) was performed with FUSION (git commit 4635dd1) [@gusev2016fusion] using ROSMAP/Banner DLPFC PWAS SNP-weights and pQTL/eQTL (SMR) (Synapse syn23627957) [@rosmap_banner] protein SNP-weight panels (Brain - DLPFC (ROSMAP) and Brain - DLPFC (Banner)). Associations were FDR-corrected across panels. Colocalisation was assessed with coloc (v3.1) [@giambartolomei2014coloc].

Summary-data-based Mendelian randomisation (SMR) of gene expression was performed with SMR (v1.3.0) [@zhu2016smr; @wu2018smr] using PsychENCODE DLPFC cis-eQTL data (SMR) (PsychENCODE HCP100 summary) [@psychencode_smr] and eQTLGen blood cis-eQTL data (SMR) (eQTLGen phase 1) [@vosa2021eqtlgen] cis-eQTL data. SMR P-values were FDR-corrected across panels. The HEIDI test was used to distinguish pleiotropy/causality from linkage.

SMR of protein levels was performed with SMR (v1.3.0) [@zhu2016smr; @wu2018smr] using ROSMAP/Banner DLPFC PWAS SNP-weights and pQTL/eQTL (SMR) (Synapse syn23627957) [@rosmap_banner] pQTL data, with FDR correction of SMR P-values and the HEIDI heterogeneity test applied as above.

Tissue-specific enrichment of gene-level association was tested with MAGMA (v1.10) [@deleeuw2015magma] using GTEx v8 FUSION expression SNP-weights (GTEx v8) [@gtex2020] tissue expression, with FDR correction across tissues followed by conditional analysis of the significant tissues.

Candidate causal (effector) genes were prioritised within each 95% credible set with CALDERA (static binary (sha-pinned in rules/dependencies.smk)) [@heilbron2024caldera], a pretrained model that scores every nearby protein-coding gene (GENCODE protein-coding gene model (GENCODE v47 (GRCh37)) [@frankish2021gencode]) from its distance to the credible set, its gene-level polygenic priority score (Polygenic Priority Score (PoPS) (FinucaneLab/pops @ 76eb86c (pinned in rules/dependencies.smk)) [@weeks2023pops]), the credible-set posterior inclusion probability on non-synonymous variants in the gene, and the local gene density. Scores are normalised to sum to one within a credible set, giving each gene a probability of being the causal gene relative to the others at that locus.

Drug-repurposing enrichment analyses were performed as follows. Competitive drug-set enrichment was tested with MAGMA (v1.10) [@deleeuw2015magma] over the Drug Targetor gene-set database (ATC extract 2022-02-01-v3) [@fabbri2018drugtargetor]. The drugs in each ATC class were tested for enrichment three ways — a competitive Wilcoxon rank-sum of the per-drug statistics, and two correlation-aware model-based contrasts, VIF-OLS ATC-class enrichment (CAMERA-style) (GenoDisc implementation) [@wu2012camera] and GLS ATC-class enrichment (DRUGSETS-style) (GenoDisc implementation) [@bell2022drugsets] — with FDR correction applied within each ATC level. All enrichment P-values were FDR-corrected.

Pathway enrichment against user-supplied gene-set collections (MSigDB-style gene-set collection (user-supplied .gmt) (user-supplied) [@liberzon2015msigdb]) was tested with MAGMA (v1.10) [@deleeuw2015magma]. P-values were pooled across all gene sets and FDR-corrected.

All analyses were orchestrated by the GenoDisc post-GWAS pipeline (version 1.6.0) and are available through the GenoDisc web server [CITE: GenoDisc paper]. Results were explored with the GenoDisc Output Viewer [CITE: GenoDisc paper].

## Reconciliation — check before use

The following analyses were requested in the configuration but produced no results for any submitted GWAS, so they are not described above. This is expected when an analysis is restricted to certain ancestries (e.g. European-only steps run on a non-European GWAS); otherwise check the pipeline logs for failures:
- `finemap`

Generator notes (verify before publication):
- Citation for 'MSigDB-style gene-set collection (user-supplied .gmt)' is not from the curated in-app table — verify before publication.
